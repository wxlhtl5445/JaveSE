package day0906;

import java.util.Scanner;

public class Test1 {
	static char[][] a = {
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
			{'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+'},
	};
	
	static char chess = '#';

	static int r; //�к�
	static int c; //�к�
	
	public static void main(String[] args) {
		while(true) {
			printQiPan();
			step();
			if(win()) {
				printQiPan();
				String color = 
				 chess=='#'?"��":"��";
				System.out.println(color+"���ʤ");
				break;
			}
			chess = chess=='#'?'O':'#';
		}
	}

	private static boolean win() {
		//����
		int[][] fx = {
				{1,0},
				{1,1},
				{0,1},
				{-1,1},
		};
		//�����ĸ�����
		for(int i=0;i<4;i++) {
			int count = 1;//����
			//������������
			mid:
			for(int j=1; j>=-1; j-=2) {
				//4��λ��
				for(int k=1; k<=4; k++) {
					//r��,c������һ����
					//����ƫ��λ�ã���ͬɫ����
					int dr = fx[i][1]*k*j + r;
					int dc = fx[i][0]*k*j + c;
					if(dr<0 || dr>15 || dc<0 || dc>15) {
						continue mid;
					}
					
					if(chess == a[dr][dc]) {
						count++;
						if(count==5) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	
	

	private static void printQiPan() {
		System.out.println(" 0123456789abcdef");
		for(int i=0;i<16;i++) {
			System.out.print(Integer.toHexString(i));
			for(int j=0;j<16;j++) {
				System.out.print(a[i][j]);
			}
			System.out.println();
		}
	}

	private static void step() {
		while(true) {
			System.out.println("���壺");
			String s1 = new Scanner(System.in).nextLine();
			String s2 = new Scanner(System.in).nextLine();
			
			r = Integer.parseInt(s1, 16);
			c = Integer.parseInt(s2, 16);
			
			if(r<0 || r>15 || c<0 || c>15) {
				System.out.println("���������������");
				continue;
			}
			if(a[r][c]!='+') {
				System.out.println("�����Ѿ���������");
				continue;
			}			
			a[r][c] = chess;
			break;
		}
	}
}






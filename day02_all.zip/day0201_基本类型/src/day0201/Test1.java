package day0201;

public class Test1 {
	public static void main(String[] args) {
		char c1 = 'a';
		char c2 = 97;
		char c3 = 'b';
		char c4 = 98;
		char c5 = '��';
		char c6 = 20013;
		char c7 = 20014;
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		System.out.println(c7);
		System.out.println("--------------");
		char c8 = '\u0061';
		char c9 = '\u4e2d';
		char c10 = '\u4e2e';
		System.out.println(c8);
		System.out.println(c9);
		System.out.println(c10);
		
	}
}




package day1206;

public class Test1 {

}

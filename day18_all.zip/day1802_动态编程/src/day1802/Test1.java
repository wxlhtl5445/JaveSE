package day1802;

public class Test1 {
	public static void main(String[] args) throws Exception {
		Runner.launch();
	}
}

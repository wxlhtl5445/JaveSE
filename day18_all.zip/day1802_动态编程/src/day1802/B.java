package day1802;

public class B {
	public void b() {
		System.out.println("����");
	}
}

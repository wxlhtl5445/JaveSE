package day1802;

public class C {
	public void c() {
		System.out.println("Why?");
	}
}

package day1803;

public class Test1 {
	public static void main(String[] args) throws Exception {
		Runner.launch(A.class);
	}
}

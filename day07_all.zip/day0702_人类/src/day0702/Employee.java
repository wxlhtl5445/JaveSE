package day0702;

public class Employee extends Person {
	double salary;
	
	
}

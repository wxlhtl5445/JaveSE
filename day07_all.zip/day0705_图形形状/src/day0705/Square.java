package day0705;

public class Square  extends Shape {
	@Override
	public void draw() {
		System.out.println("��");
	}
}

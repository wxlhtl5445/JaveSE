package day0902;

public interface Weapon {
	/* public abstract */
	void kill();
}
